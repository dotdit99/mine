package 자동차만들기2;

public interface AutoPilot {
    void autoPilotOnOff(boolean isOn);
}
