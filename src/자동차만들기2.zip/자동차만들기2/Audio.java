package 자동차만들기2;

public interface Audio {
    void audioOnOff(boolean isOn); // public abstract
}
