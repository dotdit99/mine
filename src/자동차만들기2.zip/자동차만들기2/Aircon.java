package 자동차만들기2;

public interface Aircon {
    void setFuelEffi(double fuelEffi);
    double getFuelEffi();
    void airconOnOff(boolean isOn);

}